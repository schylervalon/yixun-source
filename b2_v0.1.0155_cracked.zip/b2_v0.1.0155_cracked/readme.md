亿寻下载器源代码
original.ahk 原始代码
yixun.ahk 修改去限制
accountget.ahk 账号提取
saldl,aria2为魔改修复版
内含autohotkey 1.1.32.00